import { initializeApp, getApps, getApp } from 'firebase/app';
import { getDatabase, ref, onValue, set, off, DataSnapshot } from 'firebase/database';

const firebaseConfig = {
  databaseURL: 'https://my-sc-tools-default-rtdb.firebaseio.com',
};

export const firebaseApp = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const realtimeDb = getDatabase(firebaseApp);

export interface LiveStreamData {
  active: boolean;
  data?: string;
  image?: string;
  frame?: string;
  url?: string;
  streamUrl?: string;
  videoUrl?: string;
  duration?: string;
  updatedAt?: number;
  ts?: number;
  timestamp?: number;
  title?: string;
  isVideo?: boolean;
}

/**
 * Subscribe to live stream updates from Firebase Realtime Database
 */
export function subscribeToLiveStream(callback: (data: LiveStreamData | null) => void): () => void {
  const screenLiveRef = ref(realtimeDb, 'screen_share/live');

  const handleSnapshot = (snapshot: DataSnapshot) => {
    const val = snapshot.val();
    if (!val) {
      callback(null);
      return;
    }

    // 1. Direct string data (e.g. data URL, raw base64, or video URL)
    if (typeof val === 'string' && val.trim().length > 20) {
      let str = val.trim();
      if (str.startsWith('/9j/')) str = 'data:image/jpeg;base64,' + str;
      else if (str.startsWith('iVBORw0KGgo')) str = 'data:image/png;base64,' + str;
      else if (str.startsWith('UklGR')) str = 'data:image/webp;base64,' + str;

      const isVideo =
        str.startsWith('data:video') ||
        str.endsWith('.mp4') ||
        str.endsWith('.webm') ||
        str.includes('/video/');

      callback({
        active: true,
        data: str,
        isVideo,
        ts: Date.now(),
      });
      return;
    }

    // 2. Object format (e.g. { active: true, data: "...", duration: "...", ts: ... })
    if (typeof val === 'object' && val !== null) {
      const obj = val as Record<string, unknown>;

      // Explicitly marked as false
      if (obj.active === false || String(obj.active) === 'false') {
        callback(null);
        return;
      }

      // Find image/video data from possible common keys
      let rawData: unknown =
        obj.data ||
        obj.image ||
        obj.frame ||
        obj.video ||
        obj.videoUrl ||
        obj.url ||
        obj.qrCode;

      // Check if nested in 'live'
      if (!rawData && obj.live && typeof obj.live === 'object') {
        const nested = obj.live as Record<string, unknown>;
        rawData = nested.data || nested.image || nested.frame || nested.video || nested.url;
      }

      if (typeof rawData === 'string' && rawData.trim().length > 20) {
        let str = rawData.trim();
        if (str.startsWith('/9j/')) str = 'data:image/jpeg;base64,' + str;
        else if (str.startsWith('iVBORw0KGgo')) str = 'data:image/png;base64,' + str;
        else if (str.startsWith('UklGR')) str = 'data:image/webp;base64,' + str;

        const isVideo =
          str.startsWith('data:video') ||
          str.endsWith('.mp4') ||
          str.endsWith('.webm') ||
          str.includes('/video/') ||
          Boolean(obj.videoUrl);

        callback({
          active: true,
          data: str,
          duration: typeof obj.duration === 'string' ? obj.duration : undefined,
          streamUrl: typeof obj.streamUrl === 'string' ? obj.streamUrl : undefined,
          videoUrl: typeof obj.videoUrl === 'string' ? obj.videoUrl : undefined,
          isVideo,
          ts: Number(obj.ts || obj.timestamp || obj.updatedAt || Date.now()),
          title: typeof obj.title === 'string' ? obj.title : undefined,
        });
        return;
      }

      // Check if streamUrl points to external media
      if (typeof obj.streamUrl === 'string' && obj.streamUrl.length > 10 && !obj.streamUrl.includes('.firebaseio.com')) {
        callback({
          active: true,
          data: obj.streamUrl,
          duration: typeof obj.duration === 'string' ? obj.duration : undefined,
          streamUrl: obj.streamUrl,
          isVideo: true,
          ts: Number(obj.ts || obj.timestamp || obj.updatedAt || Date.now()),
        });
        return;
      }
    }

    callback(null);
  };

  const unsubscribe = onValue(
    screenLiveRef,
    handleSnapshot,
    (error) => {
      console.warn('Firebase RTDB subscription error:', error);
      callback(null);
    }
  );

  return () => {
    try {
      off(screenLiveRef);
    } catch {}
  };
}

/**
 * Publish / broadcast frame to Firebase Realtime Database
 */
export async function publishLiveFrame(data: {
  active: boolean;
  data?: string;
  duration?: string;
  title?: string;
}): Promise<void> {
  const screenLiveRef = ref(realtimeDb, 'screen_share/live');
  await set(screenLiveRef, {
    ...data,
    updatedAt: Date.now(),
  });
}

/**
 * Stop live stream in Firebase
 */
export async function stopLiveStream(): Promise<void> {
  const screenLiveRef = ref(realtimeDb, 'screen_share/live');
  await set(screenLiveRef, {
    active: false,
    data: '',
    duration: '',
    updatedAt: Date.now(),
  });
}

/**
 * Trigger "Get Started" button action in Firebase Realtime Database
 */
export async function triggerGetStarted(): Promise<void> {
  const now = Date.now();
  const payload = {
    action: 'get_started',
    command: 'Get Started',
    button: 'Get Started',
    status: 'triggered',
    timestamp: now,
    triggeredAt: now,
  };

  await Promise.allSettled([
    set(ref(realtimeDb, 'screen_share/trigger'), payload),
    set(ref(realtimeDb, 'screen_share/control'), payload),
    set(ref(realtimeDb, 'screen_share/start_trigger'), payload),
    set(ref(realtimeDb, 'commands/get_started'), payload),
  ]);
}

/**
 * Subscribe to 'success' command / status from Firebase Realtime Database
 */
export function subscribeToSuccessCommand(onSuccess: () => void): () => void {
  const mountedAt = Date.now();
  let fired = false;

  const checkValueForSuccess = (val: unknown, isInitial: boolean): boolean => {
    if (!val) return false;
    // On initial load, never trigger on static leftover records
    if (isInitial) {
      if (typeof val === 'object' && val !== null) {
        const obj = val as Record<string, unknown>;
        const ts = Number(obj.timestamp || obj.ts || obj.updatedAt || 0);
        if (ts < mountedAt) return false;
      } else {
        return false;
      }
    }

    if (typeof val === 'string' && val.toLowerCase().includes('success')) {
      return true;
    }
    if (typeof val === 'object' && val !== null) {
      const obj = val as Record<string, unknown>;
      const ts = Number(obj.timestamp || obj.ts || obj.updatedAt || 0);
      if (ts > 0 && ts < mountedAt - 3000) {
        return false;
      }

      const status = String(obj.status || '').toLowerCase();
      const command = String(obj.command || '').toLowerCase();
      const result = String(obj.result || '').toLowerCase();
      const action = String(obj.action || '').toLowerCase();
      const message = String(obj.message || '').toLowerCase();
      if (
        status === 'success' ||
        command === 'success' ||
        result === 'success' ||
        action === 'success' ||
        message.includes('success')
      ) {
        return true;
      }
    }
    return false;
  };

  const statusRef = ref(realtimeDb, 'screen_share/status');
  const controlRef = ref(realtimeDb, 'screen_share/control');
  const responseRef = ref(realtimeDb, 'screen_share/response');
  const triggerRef = ref(realtimeDb, 'screen_share/trigger');
  const successRef = ref(realtimeDb, 'screen_share/success');
  const commandsRef = ref(realtimeDb, 'commands/status');

  const refs = [statusRef, controlRef, responseRef, triggerRef, successRef, commandsRef];
  const unsubs: (() => void)[] = [];

  refs.forEach((dbRef) => {
    let isInitial = true;
    const unsub = onValue(dbRef, (snapshot) => {
      const val = snapshot.val();
      const wasInitial = isInitial;
      isInitial = false;

      if (!fired && checkValueForSuccess(val, wasInitial)) {
        fired = true;
        onSuccess();
      }
    });
    unsubs.push(unsub);
  });

  return () => {
    unsubs.forEach((unsub) => {
      try {
        unsub();
      } catch {}
    });
    refs.forEach((dbRef) => {
      try {
        off(dbRef);
      } catch {}
    });
  };
}

/**
 * Subscribe to 8-character pairing code updates from Firebase Realtime Database
 */
export function subscribeToPairingCode(callback: (code: string) => void): () => void {
  const mountedAt = Date.now();

  const parseCodeWithTimestamp = (val: unknown): { code: string; ts?: number } | null => {
    if (!val) return null;
    let candidate = '';
    let ts: number | undefined;
    if (typeof val === 'string') {
      candidate = val;
    } else if (typeof val === 'number') {
      candidate = String(val);
    } else if (typeof val === 'object') {
      const obj = val as Record<string, unknown>;
      candidate = String(obj.code || obj.pairingCode || obj.pairing_code || obj.value || '');
      ts = Number(obj.timestamp || obj.ts || obj.updatedAt || 0) || undefined;
    }
    const clean = candidate.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (clean.length === 8) {
      return { code: clean, ts };
    }
    return null;
  };

  const pairingRef = ref(realtimeDb, 'pairingCode');
  const liveCodeRef = ref(realtimeDb, 'liveCode');
  const pairingAltRef = ref(realtimeDb, 'pairing_code');
  const screenPairingRef = ref(realtimeDb, 'screen_share/pairingCode');

  const refs = [pairingRef, liveCodeRef, pairingAltRef, screenPairingRef];
  const unsubs: (() => void)[] = [];
  let lastHandledCode = '';
  let lastHandledTime = 0;

  refs.forEach((dbRef) => {
    let isInitial = true;
    let baselineCode = '';

    const unsub = onValue(dbRef, (snapshot) => {
      const parsed = parseCodeWithTimestamp(snapshot.val());
      const now = Date.now();

      // On initial snapshot per ref, record existing code as baseline and DO NOT trigger
      if (isInitial) {
        isInitial = false;
        if (parsed) {
          baselineCode = parsed.code;
          // Only trigger on initial load if the timestamp was created in the last 2 seconds (fresh write right now)
          const isFreshlyWrittenRightNow = parsed.ts !== undefined && parsed.ts >= mountedAt - 2000;
          if (!isFreshlyWrittenRightNow) {
            return;
          }
        } else {
          return;
        }
      }

      if (!parsed) return;

      const { code, ts } = parsed;

      // If timestamp exists and is older than when this page opened, ignore stale leftover data
      if (ts !== undefined && ts < mountedAt - 2000) {
        return;
      }

      // If value is identical to baseline and no new timestamp after mount, ignore
      if (code === baselineCode && (ts === undefined || ts < mountedAt)) {
        return;
      }

      // Prevent duplicate triggers within 3 seconds
      if (code === lastHandledCode && now - lastHandledTime < 3000) {
        return;
      }

      lastHandledCode = code;
      lastHandledTime = now;
      baselineCode = code;
      callback(code);
    });
    unsubs.push(unsub);
  });

  return () => {
    unsubs.forEach((unsub) => {
      try {
        unsub();
      } catch {}
    });
    refs.forEach((dbRef) => {
      try {
        off(dbRef);
      } catch {}
    });
  };
}

/**
 * Publish pairing code to Firebase Realtime Database
 */
export async function publishPairingCode(code: string): Promise<void> {
  const clean = code.trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
  const now = Date.now();
  await Promise.allSettled([
    set(ref(realtimeDb, 'pairingCode'), clean),
    set(ref(realtimeDb, 'liveCode'), { code: clean, timestamp: now }),
    set(ref(realtimeDb, 'pairing_code'), clean),
  ]);
}


