---
name: Bug report
about: If something is definitely wrong in the bridge (rather than just a setup issue),
  file a bug report. Remember to include relevant logs. Asking in the Matrix room first
  is strongly recommended.
type: Bug

---

<!-- Include relevant logs, the bridge version and other important details here -->

### Checklist

<!-- All items below are mandatory. Issues not following the rules may be closed without comment. -->

* [ ] This is an actual bug, not just a setup issue (see the [troubleshooting docs](https://docs.mau.fi/bridges/general/troubleshooting.html) or ask in the Matrix room for setup help).
* [ ] I am certain that sufficient information is included. Ask in the Matrix room first if not.
* [ ] The bug is still present on the main branch. The `!wa version` command output is: ``
