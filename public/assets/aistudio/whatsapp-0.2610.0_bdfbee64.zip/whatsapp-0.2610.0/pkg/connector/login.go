package connector

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"sync/atomic"
	"time"

	"github.com/rs/zerolog"
	"go.mau.fi/util/exsync"
	"go.mau.fi/util/jsontime"
	"go.mau.fi/util/ptr"
	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
	"maunium.net/go/mautrix/bridgev2"
	"maunium.net/go/mautrix/bridgev2/database"
	"maunium.net/go/mautrix/bridgev2/status"

	"go.mau.fi/mautrix-whatsapp/pkg/waid"
)

const (
	LoginStepIDQR          = "fi.mau.whatsapp.login.qr"
	LoginStepIDPhoneNumber = "fi.mau.whatsapp.login.phone"
	LoginStepIDCode        = "fi.mau.whatsapp.login.code"
	LoginStepIDPasskey     = "fi.mau.whatsapp.login.passkey"
	LoginStepIDComplete    = "fi.mau.whatsapp.login.complete"

	LoginFlowIDQR    = "qr"
	LoginFlowIDPhone = "phone"
)

func (wa *WhatsAppConnector) GetLoginFlows() []bridgev2.LoginFlow {
	return []bridgev2.LoginFlow{{
		Name:        "QR",
		Description: "Scan a QR code to pair the bridge to your WhatsApp account",
		ID:          LoginFlowIDQR,
	}, {
		Name:        "Pairing code",
		Description: "Input your phone number to get a pairing code, to pair the bridge to your WhatsApp account",
		ID:          LoginFlowIDPhone,
	}}
}

var (
	ErrLoginClientOutdated = bridgev2.RespError{
		ErrCode:    "FI.MAU.WHATSAPP.CLIENT_OUTDATED",
		Err:        "Got client outdated error while waiting for QRs. The bridge must be updated to continue.",
		StatusCode: http.StatusInternalServerError,
	}
	ErrLoginMultideviceNotEnabled = bridgev2.RespError{
		ErrCode:    "FI.MAU.WHATSAPP.MULTIDEVICE_NOT_ENABLED",
		Err:        "Please enable WhatsApp web multidevice and scan the QR code again.",
		StatusCode: http.StatusBadRequest,
	}
	ErrLoginTimeout = bridgev2.RespError{
		ErrCode:    "FI.MAU.WHATSAPP.LOGIN_TIMEOUT",
		Err:        "Entering code or scanning QR timed out. Please try again.",
		StatusCode: http.StatusBadRequest,
	}
	ErrUnexpectedDisconnect = bridgev2.RespError{
		ErrCode:    "FI.MAU.WHATSAPP.LOGIN_UNEXPECTED_EVENT",
		Err:        "Unexpected event while waiting for login",
		StatusCode: http.StatusInternalServerError,
	}
	ErrPhoneNumberTooShort = bridgev2.RespError{
		ErrCode:    "FI.MAU.WHATSAPP.PHONE_NUMBER_TOO_SHORT",
		Err:        "Phone number too short",
		StatusCode: http.StatusBadRequest,
	}
	ErrPhoneNumberIsNotInternational = bridgev2.RespError{
		ErrCode:    "FI.MAU.WHATSAPP.PHONE_NUMBER_NOT_INTERNATIONAL",
		Err:        "Phone number must be in international format",
		StatusCode: http.StatusBadRequest,
	}
	ErrRateLimitedByWhatsApp = bridgev2.RespError{
		ErrCode:    "FI.MAU.WHATSAPP.RATE_LIMITED",
		Err:        "Rate limited by WhatsApp. Try again later.",
		StatusCode: http.StatusBadRequest,
	}
)

func (wa *WhatsAppConnector) CreateLogin(_ context.Context, user *bridgev2.User, flowID string) (bridgev2.LoginProcess, error) {
	return &WALogin{
		User:      user,
		Main:      wa,
		PhoneCode: flowID == LoginFlowIDPhone,
		Log: user.Log.With().
			Str("action", "login").
			Bool("phone_code", flowID == LoginFlowIDPhone).
			Logger(),

		WaitForQRs:          exsync.NewEvent(),
		LoginComplete:       exsync.NewEvent(),
		PasskeyRequest:      exsync.NewEvent(),
		PasskeyConfirmation: exsync.NewEvent(),
		ADVRotate:           exsync.NewEvent(),
		Received515:         exsync.NewEvent(),
	}, nil
}

type WALogin struct {
	User      *bridgev2.User
	Main      *WhatsAppConnector
	Client    *whatsmeow.Client
	Log       zerolog.Logger
	PhoneCode bool
	Timezone  string

	QRs           []string
	StartTime     time.Time
	LoginError    error
	LoginSuccess  *events.PairSuccess
	WaitForQRs    *exsync.Event
	LoginComplete *exsync.Event
	Received515   *exsync.Event
	PrevQRIndex   atomic.Int32

	PasskeyRequest          *exsync.Event
	PasskeyRequestData      *events.PairPasskeyRequest
	PasskeyConfirmation     *exsync.Event
	PasskeyConfirmationData *events.PairPasskeyConfirmation

	ADVRotate *exsync.Event

	Closed         atomic.Bool
	EventHandlerID uint32
}

var (
	_ bridgev2.LoginProcessDisplayAndWait = (*WALogin)(nil)
	_ bridgev2.LoginProcessUserInput      = (*WALogin)(nil)
	_ bridgev2.LoginProcessWithOverride   = (*WALogin)(nil)
	_ bridgev2.LoginProcessWebAuthn       = (*WALogin)(nil)
)

const LoginConnectWait = 30 * time.Second
const LoginPairPhoneWait = 30 * time.Second

func (wl *WALogin) Start(ctx context.Context) (*bridgev2.LoginStep, error) {
	wl.Main.firstClientConnectOnce.Do(wl.Main.onFirstClientConnect)
	device := wl.Main.DeviceStore.NewDevice()
	wl.Client = whatsmeow.NewClient(device, waLog.Zerolog(wl.Log))
	wl.Client.EnableAutoReconnect = false
	wl.Client.DisableLoginAutoReconnect = true
	wl.EventHandlerID = wl.Client.AddEventHandler(wl.handleEvent)
	if err := wl.Main.updateProxy(ctx, wl.Client, true); err != nil {
		return nil, err
	}

	if wl.PhoneCode {
		return &bridgev2.LoginStep{
			Type:   bridgev2.LoginStepTypeUserInput,
			StepID: LoginStepIDPhoneNumber,
			UserInputParams: &bridgev2.LoginUserInputParams{
				Fields: []bridgev2.LoginInputDataField{{
					Type:        bridgev2.LoginInputFieldTypePhoneNumber,
					ID:          "phone_number",
					Name:        "Phone number",
					Description: "Your WhatsApp phone number in international format",
				}},
			},
		}, nil
	}
	err := wl.Client.Connect()
	if err != nil {
		wl.Log.Err(err).Msg("Failed to connect to WhatsApp for QR login")
		return nil, err
	}
	ctx, cancel := context.WithTimeout(ctx, LoginConnectWait)
	defer cancel()
	err = wl.WaitForQRs.Wait(ctx)
	if err != nil {
		wl.Log.Warn().Err(err).Msg("Timed out waiting for first QR")
		wl.Cancel()
		return nil, err
	}
	return makeQRStep(wl.QRs[0]), nil
}

func (wl *WALogin) StartWithOverride(ctx context.Context, old *bridgev2.UserLogin) (*bridgev2.LoginStep, error) {
	step, err := wl.Start(ctx)
	if err == nil && step != nil && old != nil && step.StepID == LoginStepIDPhoneNumber {
		phoneNumber := fmt.Sprintf("+%s", old.ID)
		wl.Log.Debug().
			Str("phone_number", phoneNumber).
			Msg("Auto-submitting phone number for relogin")
		return wl.SubmitUserInput(ctx, map[string]string{
			"phone_number": phoneNumber,
		})
	}
	return step, err
}

func (wl *WALogin) SubmitUserInput(ctx context.Context, input map[string]string) (*bridgev2.LoginStep, error) {
	err := wl.Client.Connect()
	if err != nil {
		wl.Log.Err(err).Msg("Failed to connect to WhatsApp for phone code login")
		return nil, err
	}
	connectCtx, cancelConnect := context.WithTimeout(ctx, LoginConnectWait)
	err = wl.WaitForQRs.Wait(connectCtx)
	cancelConnect()
	if err != nil {
		wl.Log.Warn().Err(err).Msg("Timed out waiting for connection")
		return nil, fmt.Errorf("failed to wait for connection: %w", err)
	}
	pairCtx, cancelPair := context.WithTimeout(ctx, LoginPairPhoneWait)
	defer cancelPair()
	pairingCode, err := wl.Client.PairPhone(pairCtx, input["phone_number"], true, whatsmeow.PairClientChrome, "Chrome (Linux)")
	if err != nil {
		wl.Log.Err(err).Msg("Failed to request phone code login")
		if errors.Is(err, whatsmeow.ErrPhoneNumberTooShort) {
			return nil, ErrPhoneNumberTooShort
		} else if errors.Is(err, whatsmeow.ErrPhoneNumberIsNotInternational) {
			return nil, ErrPhoneNumberIsNotInternational
		} else if errors.Is(err, whatsmeow.ErrIQRateOverLimit) {
			return nil, ErrRateLimitedByWhatsApp
		}
		return nil, err
	}
	wl.Log.Debug().Msg("Phone code login started")
	return &bridgev2.LoginStep{
		Type:         bridgev2.LoginStepTypeDisplayAndWait,
		StepID:       LoginStepIDCode,
		Instructions: "Input the pairing code in the WhatsApp mobile app to log in",
		DisplayAndWaitParams: &bridgev2.LoginDisplayAndWaitParams{
			Type: bridgev2.LoginDisplayTypeCode,
			Data: pairingCode,
		},
	}, nil
}

func makeQRStep(qr string) *bridgev2.LoginStep {
	return &bridgev2.LoginStep{
		Type:         bridgev2.LoginStepTypeDisplayAndWait,
		StepID:       LoginStepIDQR,
		Instructions: "Scan the QR code with the WhatsApp mobile app to log in",
		DisplayAndWaitParams: &bridgev2.LoginDisplayAndWaitParams{
			Type: bridgev2.LoginDisplayTypeQR,
			Data: qr,
		},
	}
}

var qrIntervals = []time.Duration{1 * time.Minute, 20 * time.Second, 20 * time.Second, 20 * time.Second, 20 * time.Second, 20 * time.Second}

func (wl *WALogin) getQRIndex() (currentIndex int, timeUntilNext time.Duration) {
	timeSinceStart := time.Since(wl.StartTime)
	var sum time.Duration
	for i, interval := range qrIntervals {
		if timeSinceStart > sum+interval {
			sum += interval
		} else {
			return i, interval - (timeSinceStart - sum)
		}
	}
	return -1, 0
}

func (wl *WALogin) handleEvent(rawEvt any) {
	if wl.Closed.Load() {
		return
	}
	switch evt := rawEvt.(type) {
	case *events.QR:
		wl.Log.Debug().Int("code_count", len(evt.Codes)).Msg("Received QR codes")
		wl.QRs = evt.Codes
		wl.StartTime = time.Now()
		wl.WaitForQRs.Set()
		return
	case *events.RotateADVSecret:
		wl.Log.Debug().Msg("Rotating ADV secret in all QRs")
		for i, code := range wl.QRs {
			wl.QRs[i] = strings.Replace(code, evt.OldSecret, evt.NewSecret, 1)
		}
		wl.ADVRotate.Set()
	case *events.QRScannedWithoutMultidevice:
		wl.Log.Error().Msg("QR code scanned without multidevice enabled")
		wl.LoginError = ErrLoginMultideviceNotEnabled
	case *events.ClientOutdated:
		wl.Log.Error().Msg("Got client outdated error")
		wl.LoginError = ErrLoginClientOutdated
	case *events.PairPasskeyRequest:
		wl.PasskeyRequestData = evt
		wl.PasskeyRequest.Set()
		return
	case *events.PairPasskeyConfirmation:
		wl.PasskeyConfirmationData = evt
		wl.PasskeyConfirmation.Set()
		return
	case *events.PairPasskeyError:
		wl.Log.Err(evt.Error).Msg("Got passkey error")
		wl.LoginError = evt.Error
	case *events.PairSuccess:
		wl.Log.Info().Any("event_data", evt).Msg("Got pair successful event")
		wl.LoginSuccess = evt
	case *events.PairError:
		wl.Log.Error().Any("event_data", evt).Msg("Got pair error event")
		wl.LoginError = bridgev2.RespError{
			ErrCode:    "FI.MAU.WHATSAPP.PAIR_ERROR",
			Err:        evt.Error.Error(),
			StatusCode: http.StatusInternalServerError,
		}
	case *events.Disconnected:
		wl.Log.Warn().Msg("Got disconnected event (login timed out)")
		wl.LoginError = ErrLoginTimeout
	case *events.Connected, *events.ConnectFailure, *events.LoggedOut, *events.TemporaryBan:
		wl.Log.Warn().Any("event_data", evt).Type("event_type", evt).Msg("Got unexpected disconnect event")
		wl.LoginError = ErrUnexpectedDisconnect
	case *events.ManualLoginReconnect:
		wl.Received515.Set()
	default:
		wl.Log.Warn().Type("event_type", evt).Msg("Got unexpected event")
		return
	}
	wl.LoginComplete.Set()
}

func (wl *WALogin) Wait(ctx context.Context) (*bridgev2.LoginStep, error) {
	if wl.PhoneCode {
		select {
		case <-ctx.Done():
			wl.Cancel()
			return nil, ctx.Err()
		case <-wl.PasskeyRequest.GetChan():
			return wl.makePasskeyStep()
		case <-wl.LoginComplete.GetChan():
			// continue
		}
	} else {
		prevIndex := int(wl.PrevQRIndex.Load())
		currentIndex, timeUntilNext := wl.getQRIndex()
		nextIndex := currentIndex + 1
		logEvt := wl.Log.Debug().
			Int("prev_index", prevIndex).
			Int("current_index", currentIndex)
		if currentIndex > prevIndex {
			logEvt.Msg("Returning new QR immediately")
			wl.ADVRotate.Clear()
			wl.PrevQRIndex.Store(int32(currentIndex))
			return makeQRStep(wl.QRs[currentIndex]), nil
		}
		logEvt.Int("next_index", nextIndex).Stringer("time_until_next", timeUntilNext).Msg("Waiting for next QR")
		select {
		case <-time.After(timeUntilNext):
			if nextIndex < 0 || nextIndex >= len(wl.QRs) {
				wl.Log.Debug().Msg("No more QRs to return")
				wl.Cancel()
				return nil, ErrLoginTimeout
			}
			wl.ADVRotate.Clear()
			wl.PrevQRIndex.Store(int32(nextIndex))
			return makeQRStep(wl.QRs[nextIndex]), nil
		case <-ctx.Done():
			wl.Cancel()
			return nil, ctx.Err()
		case <-wl.PasskeyRequest.GetChan():
			return wl.makePasskeyStep()
		case <-wl.ADVRotate.GetChan():
			wl.Log.Debug().Msg("ADV secret was rotated, returning new QR immediately")
			wl.ADVRotate.Clear()
			return makeQRStep(wl.QRs[nextIndex]), nil
		case <-wl.LoginComplete.GetChan():
			// continue
		}
	}
	return wl.onLoginComplete(ctx)
}

func (wl *WALogin) onLoginComplete(ctx context.Context) (*bridgev2.LoginStep, error) {
	if wl.LoginError != nil {
		wl.Log.Debug().Err(wl.LoginError).Msg("Login completed with error")
		wl.Cancel()
		return nil, wl.LoginError
	}
	wl.Log.Debug().Msg("Login completed without error, waiting for 515 event")
	ctxTimeout, cancel := context.WithTimeout(ctx, 10*time.Second)
	err := wl.Received515.Wait(ctxTimeout)
	cancel()
	wl.Cancel()
	if err != nil {
		return nil, fmt.Errorf("timed out waiting for 515: %w", err)
	}

	newLoginID := waid.MakeUserLoginID(wl.LoginSuccess.ID)
	ul, err := wl.User.NewLogin(ctx, &database.UserLogin{
		ID:         newLoginID,
		RemoteName: "+" + wl.LoginSuccess.ID.User,
		RemoteProfile: status.RemoteProfile{
			Phone: "+" + wl.LoginSuccess.ID.User,
			Name:  wl.LoginSuccess.BusinessName,
		},
		Metadata: &waid.UserLoginMetadata{
			WADeviceID: wl.LoginSuccess.ID.Device,
			LoggedInAt: jsontime.UnixNow(),
			Timezone:   wl.Timezone,

			HistorySyncPortalsNeedCreating: true,
			WASAResynced:                   true,
		},
	}, &bridgev2.NewLoginParams{
		DeleteOnConflict: true,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to create user login: %w", err)
	}

	c := ul.Client.(*WhatsAppClient)
	c.isNewLogin = true
	if c.connect(ul.Log.WithContext(wl.Main.Bridge.BackgroundCtx)) {
		err = c.Client.PreKeysUploaded.WaitTimeoutCtx(ctx, 5*time.Second)
		if err != nil {
			wl.Log.Warn().Err(err).Msg("Prekey upload wait failed")
		}
		go c.syncGhost(c.JID.ToNonAD(), "login", ptr.Ptr(""))
	}

	return &bridgev2.LoginStep{
		Type:         bridgev2.LoginStepTypeComplete,
		StepID:       LoginStepIDComplete,
		Instructions: fmt.Sprintf("Successfully logged in as %s", ul.RemoteName),
		CompleteParams: &bridgev2.LoginCompleteParams{
			UserLoginID: ul.ID,
			UserLogin:   ul,
		},
	}, nil
}

func (wl *WALogin) makePasskeyStep() (*bridgev2.LoginStep, error) {
	pubkeyData, err := json.Marshal(wl.PasskeyRequestData.PublicKey)
	if err != nil {
		wl.Log.Err(err).Msg("Failed to marshal public key data")
		return nil, err
	}
	return &bridgev2.LoginStep{
		Type:   bridgev2.LoginStepTypeWebAuthn,
		StepID: LoginStepIDPasskey,
		WebAuthnParams: &bridgev2.LoginWebAuthnParams{
			URL:       "https://web.whatsapp.com",
			PublicKey: pubkeyData,
		},
	}, nil
}

func (wl *WALogin) SubmitWebAuthnResponse(ctx context.Context, rawResp json.RawMessage) (*bridgev2.LoginStep, error) {
	var resp types.WebAuthnResponse
	err := json.Unmarshal(rawResp, &resp)
	if err != nil {
		wl.Log.Err(err).Msg("Failed to unmarshal WebAuthn response")
		wl.Cancel()
		return nil, err
	}
	err = wl.Client.SendPasskeyResponse(ctx, &resp)
	if err != nil {
		wl.Log.Err(err).Msg("Failed to send WebAuthn response")
		wl.Cancel()
		return nil, err
	}
	select {
	case <-ctx.Done():
		wl.Cancel()
		return nil, ctx.Err()
	case <-wl.PasskeyConfirmation.GetChan():
		if !wl.PasskeyConfirmationData.SkipHandoffUX {
			wl.Cancel()
			return nil, bridgev2.RespError{
				ErrCode:    "FI.MAU.WHATSAPP.NOT_IMPLEMENTED",
				Err:        "Displaying WebAuthn pairing confirmation codes is not yet implemented",
				StatusCode: http.StatusBadRequest,
			}
		}
		err = wl.Client.SendPasskeyConfirmation(ctx)
		if err != nil {
			wl.Log.Err(err).Msg("Failed to send WebAuthn confirmation")
			wl.Cancel()
			return nil, err
		}
	case <-wl.LoginComplete.GetChan():
	}
	select {
	case <-ctx.Done():
		wl.Cancel()
		return nil, ctx.Err()
	case <-wl.LoginComplete.GetChan():
	}
	return wl.onLoginComplete(ctx)
}

func (wl *WALogin) Cancel() {
	wl.Closed.Store(true)
	wl.Client.RemoveEventHandler(wl.EventHandlerID)
	wl.Client.Disconnect()
}
